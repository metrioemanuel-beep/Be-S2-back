import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);

        System.out.println("===== SISTEMA DE CONTROL DE ACCESO =====");

        // Registrar persona
        System.out.println("\n===== REGISTRAR PERSONA =====");

        System.out.print("Nombre: ");
        String nombre = teclado.nextLine();

        System.out.print("Documento: ");
        String documento = teclado.nextLine();

        System.out.print("Edad: ");
        int edad = teclado.nextInt();
        teclado.nextLine();

        Persona persona = new Persona(nombre, documento, edad);

        // Crear registro de accesos
        RegistroAccesos registro = new RegistroAccesos();

        int opcion;

        do {

            System.out.println("\n===== MENÚ =====");
            System.out.println("1. Mostrar persona");
            System.out.println("2. Registrar entrada");
            System.out.println("3. Registrar salida");
            System.out.println("4. Mostrar accesos");
            System.out.println("5. Mostrar cantidad de accesos");
            System.out.println("6. Salir");

            System.out.print("Seleccione una opción: ");

            opcion = teclado.nextInt();
            teclado.nextLine();

            switch (opcion) {

                case 1:

                    System.out.println("\n===== DATOS DE LA PERSONA =====");

                    persona.mostrarInformacion();

                    break;

                case 2:

                    System.out.print("Ingrese la fecha: ");
                    String fechaEntrada = teclado.nextLine();

                    System.out.print("Ingrese la hora: ");
                    String horaEntrada = teclado.nextLine();

                    Acceso entrada = new Acceso(
                            persona,
                            fechaEntrada,
                            horaEntrada,
                            "entrada"
                    );

                    registro.registrarAcceso(entrada);

                    break;

                case 3:

                    System.out.print("Ingrese la fecha: ");
                    String fechaSalida = teclado.nextLine();

                    System.out.print("Ingrese la hora: ");
                    String horaSalida = teclado.nextLine();

                    Acceso salida = new Acceso(
                            persona,
                            fechaSalida,
                            horaSalida,
                            "salida"
                    );

                    registro.registrarAcceso(salida);

                    break;

                case 4:

                    registro.mostrarAccesos();

                    break;

                case 5:

                    System.out.println(
                            "Cantidad de accesos: "
                            + registro.cantidadAccesos()
                    );

                    break;

                case 6:

                    System.out.println("Programa finalizado.");

                    break;

                default:

                    System.out.println("Opción no válida.");
            }

        } while (opcion != 6);

        teclado.close();
    }
}