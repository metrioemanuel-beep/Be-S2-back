public class Persona {

    private String nombre;
    private String documento;
    private int edad;

    // Constructor vacío
    public Persona() {
    }

    // Constructor con todos los atributos
    public Persona(String nombre, String documento, int edad) {
        this.nombre = nombre;
        this.documento = documento;
        setEdad(edad);
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getDocumento() {
        return documento;
    }

    public int getEdad() {
        return edad;
    }

    // Setters
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public void setEdad(int edad) {
        if (edad >= 0) {
            this.edad = edad;
        } else {
            System.out.println("La edad no puede ser negativa.");
        }
    }

    // Mostrar información
    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Documento: " + documento);
        System.out.println("Edad: " + edad);
    }
}