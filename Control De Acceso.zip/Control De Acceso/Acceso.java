public class Acceso {

    private Persona persona;
    private String fecha;
    private String hora;
    private String tipo;

    // Constructor vacío
    public Acceso() {
    }

    // Constructor con todos los atributos
    public Acceso(Persona persona, String fecha, String hora, String tipo) {
        this.persona = persona;
        this.fecha = fecha;
        this.hora = hora;
        setTipo(tipo);
    }

    // Getters
    public Persona getPersona() {
        return persona;
    }

    public String getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public String getTipo() {
        return tipo;
    }

    // Setters
    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public void setTipo(String tipo) {

        if (tipo.equalsIgnoreCase("entrada")
                || tipo.equalsIgnoreCase("salida")) {

            this.tipo = tipo;

        } else {

            System.out.println("El tipo debe ser entrada o salida.");
        }
    }

    // Mostrar acceso
    public void mostrarAcceso() {
        System.out.println("Persona: " + persona.getNombre());
        System.out.println("Documento: " + persona.getDocumento());
        System.out.println("Fecha: " + fecha);
        System.out.println("Hora: " + hora);
        System.out.println("Tipo: " + tipo);
    }
}