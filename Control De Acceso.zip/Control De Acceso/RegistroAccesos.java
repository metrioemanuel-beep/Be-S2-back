import java.util.ArrayList;

public class RegistroAccesos {

    private ArrayList<Acceso> accesos;

    // Constructor
    public RegistroAccesos() {
        accesos = new ArrayList<>();
    }

    // Registrar acceso
    public void registrarAcceso(Acceso acceso) {

        accesos.add(acceso);

        System.out.println("Acceso registrado correctamente.");
    }

    // Mostrar todos los accesos
    public void mostrarAccesos() {

        if (accesos.isEmpty()) {

            System.out.println("No hay accesos registrados.");

            return;
        }

        System.out.println("\n===== ACCESOS REGISTRADOS =====");

        for (Acceso acceso : accesos) {

            acceso.mostrarAcceso();

            System.out.println("-----------------------------");
        }
    }

    // Contar accesos
    public int cantidadAccesos() {

        return accesos.size();
    }
}