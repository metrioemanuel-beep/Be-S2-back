public class Administrador extends Usuario {

    private String cargo;
    private int nivelAcceso;

    public Administrador() {
        super();
    }

    public Administrador(String nombre, String documento, int edad, String cargo, int nivelAcceso) {
        super(nombre, documento, edad);
        this.cargo = cargo;
        setNivelAcceso(nivelAcceso);
    }

    public String getCargo() {
        return cargo;
    }

    public int getNivelAcceso() {
        return nivelAcceso;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public void setNivelAcceso(int nivelAcceso) {
        if (nivelAcceso >= 1 && nivelAcceso <= 5) {
            this.nivelAcceso = nivelAcceso;
        } else {
            System.out.println("El nivel de acceso debe estar entre 1 y 5.");
        }
    }

    @Override
    public String getRol() {
        return "Administrador";
    }

    @Override
    public boolean puedeEntrarAreaRestringida() {
        return nivelAcceso >= 3;
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Cargo: " + cargo);
        System.out.println("Nivel de acceso: " + nivelAcceso);
    }
}
