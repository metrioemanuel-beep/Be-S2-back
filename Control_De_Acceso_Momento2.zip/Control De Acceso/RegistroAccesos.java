import java.util.ArrayList;

public class RegistroAccesos implements IOperaciones<Acceso> {

    private ArrayList<Acceso> accesos;

    public RegistroAccesos() {
        accesos = new ArrayList<>();
    }

    @Override
    public boolean guardar(Acceso acceso) {
        if (acceso == null || acceso.getTipo() == null) {
            return false;
        }
        accesos.add(acceso);
        return true;
    }

    @Override
    public Acceso buscar(String documento) {
        for (int i = accesos.size() - 1; i >= 0; i--) {
            if (accesos.get(i).getUsuario().getDocumento().equals(documento)) {
                return accesos.get(i);
            }
        }
        return null;
    }

    @Override
    public boolean eliminar(String documento) {
        Acceso a = buscar(documento);
        if (a == null) {
            return false;
        }
        accesos.remove(a);
        return true;
    }

    public ArrayList<Acceso> buscarTodosPorDocumento(String documento) {
        ArrayList<Acceso> resultado = new ArrayList<>();
        for (Acceso a : accesos) {
            if (a.getUsuario().getDocumento().equals(documento)) {
                resultado.add(a);
            }
        }
        return resultado;
    }

    public void eliminarPorUsuario(String documento) {
        accesos.removeIf(a -> a.getUsuario().getDocumento().equals(documento));
    }

    public void mostrarAccesos() {
        if (accesos.isEmpty()) {
            System.out.println("No hay accesos registrados.");
            return;
        }

        System.out.println("\n===== ACCESOS REGISTRADOS =====");
        for (Acceso a : accesos) {
            a.mostrarAcceso();
            System.out.println("-----------------------------");
        }
    }

    public int cantidadAccesos() {
        return accesos.size();
    }
}
