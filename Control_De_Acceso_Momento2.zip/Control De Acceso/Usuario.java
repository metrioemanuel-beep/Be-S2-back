public abstract class Usuario {

    private String nombre;
    private String documento;
    private int edad;

    public Usuario() {
    }

    public Usuario(String nombre, String documento, int edad) {
        this.nombre = nombre;
        this.documento = documento;
        setEdad(edad);
    }

    public String getNombre() {
        return nombre;
    }

    public String getDocumento() {
        return documento;
    }

    public int getEdad() {
        return edad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public void setEdad(int edad) {
        if (edad >= 0) {
            this.edad = edad;
        } else {
            System.out.println("La edad no puede ser negativa.");
        }
    }

    public abstract String getRol();

    public abstract boolean puedeEntrarAreaRestringida();

    public void mostrarInformacion() {
        System.out.println("Rol: " + getRol());
        System.out.println("Nombre: " + nombre);
        System.out.println("Documento: " + documento);
        System.out.println("Edad: " + edad);
    }
}
