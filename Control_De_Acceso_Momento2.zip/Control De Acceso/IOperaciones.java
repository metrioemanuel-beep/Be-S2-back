public interface IOperaciones<T> {

    boolean guardar(T objeto);

    T buscar(String clave);

    boolean eliminar(String clave);
}
