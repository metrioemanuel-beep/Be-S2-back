public class Cliente extends Usuario {

    private String motivoVisita;
    private String empresa;

    public Cliente() {
        super();
    }

    public Cliente(String nombre, String documento, int edad, String motivoVisita, String empresa) {
        super(nombre, documento, edad);
        this.motivoVisita = motivoVisita;
        this.empresa = empresa;
    }

    public String getMotivoVisita() {
        return motivoVisita;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setMotivoVisita(String motivoVisita) {
        this.motivoVisita = motivoVisita;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    @Override
    public String getRol() {
        return "Cliente";
    }

    @Override
    public boolean puedeEntrarAreaRestringida() {
        return false;
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Empresa: " + empresa);
        System.out.println("Motivo de visita: " + motivoVisita);
    }
}
