import java.util.ArrayList;

public class GestorUsuarios implements IOperaciones<Usuario> {

    private ArrayList<Usuario> usuarios;

    public GestorUsuarios() {
        usuarios = new ArrayList<>();
    }

    @Override
    public boolean guardar(Usuario usuario) {
        if (usuario == null || buscar(usuario.getDocumento()) != null) {
            return false;
        }
        usuarios.add(usuario);
        return true;
    }

    @Override
    public Usuario buscar(String documento) {
        for (Usuario u : usuarios) {
            if (u.getDocumento().equals(documento)) {
                return u;
            }
        }
        return null;
    }

    @Override
    public boolean eliminar(String documento) {
        Usuario u = buscar(documento);
        if (u == null) {
            return false;
        }
        usuarios.remove(u);
        return true;
    }

    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    public void listarUsuarios() {
        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
            return;
        }

        System.out.println("\n===== USUARIOS REGISTRADOS =====");
        for (Usuario u : usuarios) {
            u.mostrarInformacion();
            System.out.println("Area restringida: " + (u.puedeEntrarAreaRestringida() ? "Si" : "No"));
            System.out.println("-----------------------------");
        }
    }

    public int cantidadUsuarios() {
        return usuarios.size();
    }

    public int contarPorRol(String rol) {
        int total = 0;
        for (Usuario u : usuarios) {
            if (u.getRol().equalsIgnoreCase(rol)) {
                total++;
            }
        }
        return total;
    }
}
