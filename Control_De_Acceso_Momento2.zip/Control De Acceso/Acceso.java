public class Acceso {

    private Usuario usuario;
    private String fecha;
    private String hora;
    private String tipo;

    public Acceso() {
    }

    public Acceso(Usuario usuario, String fecha, String hora, String tipo) {
        this.usuario = usuario;
        this.fecha = fecha;
        this.hora = hora;
        setTipo(tipo);
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public String getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public String getTipo() {
        return tipo;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public void setTipo(String tipo) {
        if (tipo != null && (tipo.equalsIgnoreCase("entrada") || tipo.equalsIgnoreCase("salida"))) {
            this.tipo = tipo.toLowerCase();
        } else {
            System.out.println("El tipo debe ser entrada o salida.");
        }
    }

    public void mostrarAcceso() {
        System.out.println("Usuario: " + usuario.getNombre() + " (" + usuario.getRol() + ")");
        System.out.println("Documento: " + usuario.getDocumento());
        System.out.println("Fecha: " + fecha);
        System.out.println("Hora: " + hora);
        System.out.println("Tipo: " + tipo);
    }
}
