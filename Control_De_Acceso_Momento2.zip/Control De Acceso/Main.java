import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static Scanner teclado = new Scanner(System.in);
    static GestorUsuarios gestorUsuarios = new GestorUsuarios();
    static RegistroAccesos registro = new RegistroAccesos();

    public static void main(String[] args) {

        cargarDatosIniciales();

        int opcion;

        do {
            mostrarMenu();
            opcion = leerEntero("Seleccione una opción: ");

            switch (opcion) {
                case 1:
                    crearUsuario();
                    break;
                case 2:
                    gestorUsuarios.listarUsuarios();
                    break;
                case 3:
                    buscarUsuario();
                    break;
                case 4:
                    actualizarUsuario();
                    break;
                case 5:
                    eliminarUsuario();
                    break;
                case 6:
                    registrarAcceso("entrada");
                    break;
                case 7:
                    registrarAcceso("salida");
                    break;
                case 8:
                    registro.mostrarAccesos();
                    break;
                case 9:
                    historialDeUsuario();
                    break;
                case 10:
                    mostrarResumen();
                    break;
                case 11:
                    System.out.println("Programa finalizado.");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }

        } while (opcion != 11);

        teclado.close();
    }

    static void mostrarMenu() {
        System.out.println("\n===== SISTEMA DE CONTROL DE ACCESO =====");
        System.out.println("1. Crear usuario");
        System.out.println("2. Listar usuarios");
        System.out.println("3. Buscar usuario");
        System.out.println("4. Actualizar usuario");
        System.out.println("5. Eliminar usuario");
        System.out.println("6. Registrar entrada");
        System.out.println("7. Registrar salida");
        System.out.println("8. Listar accesos");
        System.out.println("9. Historial de un usuario");
        System.out.println("10. Resumen");
        System.out.println("11. Salir");
    }

    static void cargarDatosIniciales() {
        gestorUsuarios.guardar(new Administrador("Laura Gomez", "1001", 34, "Jefe de seguridad", 5));
        gestorUsuarios.guardar(new Administrador("Carlos Ruiz", "1002", 41, "Coordinador", 2));
        gestorUsuarios.guardar(new Cliente("Andrea Torres", "2001", 28, "Reunión comercial", "Textiles SA"));

        registro.guardar(new Acceso(gestorUsuarios.buscar("1001"), "20/10/2026", "07:45", "entrada"));
        registro.guardar(new Acceso(gestorUsuarios.buscar("2001"), "20/10/2026", "09:10", "entrada"));
    }

    static int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(teclado.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un número entero.");
            }
        }
    }

    static String leerTexto(String mensaje) {
        String texto;
        do {
            System.out.print(mensaje);
            texto = teclado.nextLine().trim();
            if (texto.isEmpty()) {
                System.out.println("Este campo no puede quedar vacío.");
            }
        } while (texto.isEmpty());
        return texto;
    }

    static void crearUsuario() {
        System.out.println("\n===== CREAR USUARIO =====");
        System.out.println("1. Administrador");
        System.out.println("2. Cliente");
        int tipo = leerEntero("Tipo de usuario: ");

        if (tipo != 1 && tipo != 2) {
            System.out.println("Tipo no válido.");
            return;
        }

        String documento = leerTexto("Documento: ");
        if (gestorUsuarios.buscar(documento) != null) {
            System.out.println("Ya existe un usuario con ese documento.");
            return;
        }

        String nombre = leerTexto("Nombre: ");
        int edad = leerEntero("Edad: ");

        Usuario nuevo;

        if (tipo == 1) {
            String cargo = leerTexto("Cargo: ");
            int nivel = leerEntero("Nivel de acceso (1-5): ");
            nuevo = new Administrador(nombre, documento, edad, cargo, nivel);
        } else {
            String empresa = leerTexto("Empresa: ");
            String motivo = leerTexto("Motivo de la visita: ");
            nuevo = new Cliente(nombre, documento, edad, motivo, empresa);
        }

        if (gestorUsuarios.guardar(nuevo)) {
            System.out.println("Usuario guardado correctamente.");
        } else {
            System.out.println("No se pudo guardar el usuario.");
        }
    }

    static void buscarUsuario() {
        String documento = leerTexto("Documento a buscar: ");
        Usuario u = gestorUsuarios.buscar(documento);

        if (u == null) {
            System.out.println("No se encontró ningún usuario con ese documento.");
            return;
        }

        System.out.println("\n===== USUARIO ENCONTRADO =====");
        u.mostrarInformacion();
    }

    static void actualizarUsuario() {
        String documento = leerTexto("Documento del usuario a actualizar: ");
        Usuario u = gestorUsuarios.buscar(documento);

        if (u == null) {
            System.out.println("No se encontró ningún usuario con ese documento.");
            return;
        }

        System.out.println("Deje vacío (Enter) lo que no quiera cambiar.");

        System.out.print("Nombre [" + u.getNombre() + "]: ");
        String nombre = teclado.nextLine().trim();
        if (!nombre.isEmpty()) {
            u.setNombre(nombre);
        }

        System.out.print("Edad [" + u.getEdad() + "]: ");
        String edad = teclado.nextLine().trim();
        if (!edad.isEmpty()) {
            try {
                u.setEdad(Integer.parseInt(edad));
            } catch (NumberFormatException e) {
                System.out.println("Edad no válida, se deja la anterior.");
            }
        }

        if (u instanceof Administrador) {
            Administrador admin = (Administrador) u;

            System.out.print("Cargo [" + admin.getCargo() + "]: ");
            String cargo = teclado.nextLine().trim();
            if (!cargo.isEmpty()) {
                admin.setCargo(cargo);
            }

            System.out.print("Nivel de acceso [" + admin.getNivelAcceso() + "]: ");
            String nivel = teclado.nextLine().trim();
            if (!nivel.isEmpty()) {
                try {
                    admin.setNivelAcceso(Integer.parseInt(nivel));
                } catch (NumberFormatException e) {
                    System.out.println("Nivel no válido, se deja el anterior.");
                }
            }
        } else if (u instanceof Cliente) {
            Cliente cliente = (Cliente) u;

            System.out.print("Empresa [" + cliente.getEmpresa() + "]: ");
            String empresa = teclado.nextLine().trim();
            if (!empresa.isEmpty()) {
                cliente.setEmpresa(empresa);
            }

            System.out.print("Motivo de visita [" + cliente.getMotivoVisita() + "]: ");
            String motivo = teclado.nextLine().trim();
            if (!motivo.isEmpty()) {
                cliente.setMotivoVisita(motivo);
            }
        }

        System.out.println("Usuario actualizado.");
    }

    static void eliminarUsuario() {
        String documento = leerTexto("Documento del usuario a eliminar: ");

        if (gestorUsuarios.eliminar(documento)) {
            registro.eliminarPorUsuario(documento);
            System.out.println("Usuario eliminado junto con sus accesos.");
        } else {
            System.out.println("No se encontró ningún usuario con ese documento.");
        }
    }

    static void registrarAcceso(String tipo) {
        String documento = leerTexto("Documento del usuario: ");
        Usuario u = gestorUsuarios.buscar(documento);

        if (u == null) {
            System.out.println("El usuario no está registrado.");
            return;
        }

        String fecha = leerTexto("Fecha (dd/mm/aaaa): ");
        String hora = leerTexto("Hora (hh:mm): ");

        if (registro.guardar(new Acceso(u, fecha, hora, tipo))) {
            System.out.println("Acceso registrado correctamente.");
        } else {
            System.out.println("No se pudo registrar el acceso.");
        }
    }

    static void historialDeUsuario() {
        String documento = leerTexto("Documento del usuario: ");
        ArrayList<Acceso> lista = registro.buscarTodosPorDocumento(documento);

        if (lista.isEmpty()) {
            System.out.println("Ese usuario no tiene accesos registrados.");
            return;
        }

        System.out.println("\n===== HISTORIAL =====");
        for (Acceso a : lista) {
            a.mostrarAcceso();
            System.out.println("-----------------------------");
        }
    }

    static void mostrarResumen() {
        System.out.println("\n===== RESUMEN =====");
        System.out.println("Usuarios: " + gestorUsuarios.cantidadUsuarios());
        System.out.println("Administradores: " + gestorUsuarios.contarPorRol("Administrador"));
        System.out.println("Clientes: " + gestorUsuarios.contarPorRol("Cliente"));
        System.out.println("Accesos: " + registro.cantidadAccesos());

        System.out.println("\nPermisos de área restringida:");
        for (Usuario u : gestorUsuarios.getUsuarios()) {
            String permiso = u.puedeEntrarAreaRestringida() ? "puede entrar" : "no puede entrar";
            System.out.println("- " + u.getNombre() + " (" + u.getRol() + "): " + permiso);
        }
    }
}
